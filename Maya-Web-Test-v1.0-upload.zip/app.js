const $=id=>document.getElementById(id);
const reply=$("reply"), subreply=$("subreply"), statusText=$("statusText"), statusDot=$("statusDot"), orb=$("orb");
const memoryKey="maya_memory_v1", logKey="maya_log_v1";
let memory=JSON.parse(localStorage.getItem(memoryKey)||"[]");
let logs=JSON.parse(localStorage.getItem(logKey)||"[]");
let recognition=null, listening=false, lastUserText="";

function renderMemory(){
  const box=$("memoryList"); box.innerHTML="";
  if(!memory.length){box.innerHTML='<span class="empty">No saved memories yet.</span>';return}
  memory.slice(-20).forEach(x=>{const d=document.createElement("div");d.className="memory-pill";d.textContent=x;box.appendChild(d)})
}
function renderLogs(){
  const box=$("logList"); box.innerHTML="";
  if(!logs.length){box.innerHTML='<div class="empty">No activity yet.</div>';return}
  logs.slice(-20).reverse().forEach(x=>{const d=document.createElement("div");d.className="log-entry";d.innerHTML=`<strong>${escapeHtml(x.type)}</strong> · ${escapeHtml(x.text)}`;box.appendChild(d)})
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function log(type,text){logs.push({type,text,time:Date.now()});logs=logs.slice(-50);localStorage.setItem(logKey,JSON.stringify(logs));renderLogs()}
function speak(text){
  if(!("speechSynthesis" in window))return;
  speechSynthesis.cancel(); const u=new SpeechSynthesisUtterance(text); u.lang="en-IN"; u.rate=.96; u.pitch=1.04;
  const voices=speechSynthesis.getVoices(); const v=voices.find(x=>/en-IN|en-US|en-GB/i.test(x.lang)); if(v)u.voice=v;
  speechSynthesis.speak(u);
}
function setStatus(t,on=false){statusText.textContent=t;$("statusDot").parentElement.classList.toggle("listening",on);orb.classList.toggle("listening",on)}
function respond(text){reply.textContent=text;subreply.textContent="Maya is ready for your next command.";speak(text);log("Maya",text)}

function openSite(url,name){respond(`Opening ${name}.`);setTimeout(()=>window.open(url,"_blank"),250)}
function calculate(expr){
  try{
    const clean=expr.toLowerCase().replace(/what is|calculate|please|maya|hey/g,"").replace(/times/g,"*").replace(/multiplied by/g,"*").replace(/divided by/g,"/").replace(/plus/g,"+").replace(/minus/g,"-").replace(/[^0-9+\-*/().% ]/g,"").trim();
    if(!clean)return null;
    const value=Function('"use strict";return ('+clean+')')();
    return Number.isFinite(value)?value:null;
  }catch{return null}
}
function handleCommand(raw){
  const text=raw.trim(), t=text.toLowerCase(); lastUserText=text; log("You",text);
  if(!text)return;
  if(/^(hey\s+)?maya[\s,]*/i.test(text)) raw=text.replace(/^(hey\s+)?maya[\s,]*/i,"").trim();
  const q=raw.toLowerCase();

  if(/\b(time|what time)\b/.test(q)){const s=new Date().toLocaleTimeString([],{hour:"numeric",minute:"2-digit"});respond(`It is ${s}.`);return}
  if(/\b(date|today)\b/.test(q)){respond(`Today is ${new Date().toLocaleDateString(undefined,{weekday:"long",year:"numeric",month:"long",day:"numeric"})}.`);return}
  if(q.includes("open youtube")){openSite("https://www.youtube.com","YouTube");return}
  if(q.includes("open whatsapp")){openSite("https://web.whatsapp.com","WhatsApp");return}
  if(q.includes("open instagram")){openSite("https://www.instagram.com","Instagram");return}
  if(q.includes("open google")){openSite("https://www.google.com","Google");return}
  if(q.includes("clear memory")||q.includes("forget everything")){memory=[];localStorage.removeItem(memoryKey);renderMemory();respond("I cleared my local memory.");return}
  if(q.includes("what do you remember")||q.includes("show my memory")){respond(memory.length?`I remember ${memory.length} saved item${memory.length>1?"s":""}. ${memory.slice(-3).join(". ")}.`:"I don't have any saved memories yet.");return}
  if(q.startsWith("remember that")||q.startsWith("remember ")){
    const fact=raw.replace(/^remember that\s*/i,"").replace(/^remember\s*/i,"").trim();
    if(fact){memory.push(fact);memory=memory.slice(-50);localStorage.setItem(memoryKey,JSON.stringify(memory));renderMemory();respond("Got it. I saved that in local memory.");}else respond("Tell me what you want me to remember.");return
  }
  if(q.includes("notification")){
    if("Notification" in window && Notification.permission==="granted"){respond("Browser notifications are enabled for this site.")}else{respond("I can use browser notifications after you grant permission in Chrome."); if("Notification" in window)Notification.requestPermission()}return
  }
  if(q.includes("set a reminder")){
    const match=q.match(/in\s+(\d+)\s*(second|seconds|minute|minutes|hour|hours)/);
    if(match && "Notification" in window){
      const n=Number(match[1]), unit=match[2], ms=n*(unit.startsWith("second")?1000:unit.startsWith("minute")?60000:3600000);
      Notification.requestPermission().then(()=>setTimeout(()=>{if(Notification.permission==="granted")new Notification("Maya reminder",{body:"Your reminder is ready."});speak("Your reminder is ready.");},ms));
      respond(`Reminder set for ${n} ${unit}.`);return
    }
  }
  const val=calculate(raw); if(val!==null){respond(`The answer is ${val}.`);return}
  if(/^(hello|hi|hey)\b/.test(q)){respond("Hello. I'm Maya. Tell me what you want me to do.");return}
  respond("I understood your command, but that action is not connected in this web test yet. This prototype is ready for the Android action layer next.");
}

function setupSpeech(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){setStatus("Speech recognition unavailable");return}
  recognition=new SR(); recognition.lang="en-IN"; recognition.continuous=true; recognition.interimResults=true;
  recognition.onstart=()=>{listening=true;$("micBtn").classList.add("active");setStatus("Listening…",true)}
  recognition.onend=()=>{listening=false;$("micBtn").classList.remove("active");setStatus("Ready");if(window._autoListen){try{recognition.start()}catch{}}}
  recognition.onerror=e=>{setStatus("Mic error: "+e.error);setTimeout(()=>setStatus("Ready"),1800)}
  recognition.onresult=e=>{
    let finalText="";
    for(let i=e.resultIndex;i<e.results.length;i++){const r=e.results[i];if(r.isFinal)finalText+=r[0].transcript}
    if(finalText){
      const cleaned=finalText.trim();
      if(/\bhey maya\b/i.test(cleaned)||/\bmaya\b/i.test(cleaned)||window._manualCommand){window._manualCommand=false;handleCommand(cleaned)}
    }
  }
}
$("micBtn").onclick=()=>{
  if(!recognition){setupSpeech();if(!recognition)return}
  if(listening){window._autoListen=false;recognition.stop()}else{window._autoListen=true;try{recognition.start()}catch{}}
}
$("sendBtn").onclick=()=>{const v=$("commandInput").value;$("commandInput").value="";handleCommand(v)}
$("commandInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("sendBtn").click()})
$("speakBtn").onclick=()=>speak(reply.textContent)
$("stopBtn").onclick=()=>{speechSynthesis.cancel();if(recognition&&listening){window._autoListen=false;recognition.stop()}setStatus("Ready")}
document.querySelectorAll(".card").forEach(b=>b.onclick=()=>handleCommand(b.dataset.command))
$("clearMemory").onclick=()=>{memory=[];localStorage.removeItem(memoryKey);renderMemory()}
$("clearLog").onclick=()=>{logs=[];localStorage.removeItem(logKey);renderLogs()}
if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
renderMemory();renderLogs();setupSpeech();
setTimeout(()=>speak("Maya is ready."),500);
