# Maya Android/Web Test v1.0

This is a browser prototype based on the uploaded Maya 6.0.8 capability brochure.

## Test in Chrome on Android

### Fastest
1. Extract the ZIP.
2. Upload the folder/files to GitHub.
3. Enable GitHub Pages.
4. Open the generated HTTPS URL in Chrome.
5. Allow microphone and notification permissions.
6. Tap the microphone and say: "Hey Maya, what time is it?"

### Important
This prototype is a web test, not the final Android app. Browsers cannot directly provide the full Android device-control layer described in the brochure.

Included now:
- Voice input using Chrome Speech Recognition where supported
- Voice output
- "Hey Maya" command detection during listening
- Local memory using localStorage
- Basic calculator
- Website opening
- Browser notifications/reminders
- Activity log
- PWA install shell
- Mobile-first UI

Next Android layer:
- Native Kotlin service
- Android permissions
- foreground/background voice service
- Android notification listener
- accessibility action engine
- contacts/calls/SMS integrations
- Gemini Live integration
- secure local API-key storage
- native wake-word engine
- native skill/action system
